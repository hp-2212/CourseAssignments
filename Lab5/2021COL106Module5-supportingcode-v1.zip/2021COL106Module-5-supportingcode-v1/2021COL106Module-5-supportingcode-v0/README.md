How to use:
- Execute `make` to run the driver code.
- Execute `make clean` to remove the .class files
- If makefile is not working execute `javac DriverCode.java` to compile and `java DriverCode` to run
