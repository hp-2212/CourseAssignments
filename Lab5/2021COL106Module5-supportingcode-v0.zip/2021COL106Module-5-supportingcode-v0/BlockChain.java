import Includes.*;
import java.util.List;

public class BlockChain{
	// PLEASE USE YOUR ENTRY NUMBER AS THE START STRING
	public static final String start_string = "LabModule5";
	public Node firstBlock;
	public Node lastBlock;

	/*
		Note that the Exceptions have already been defined for you in the includes file,
		you just have to raise them accordingly

	*/

	public String InsertBlock(List<Pair<String,Integer>> Documents, int inputyear){
		/*
			Implement Code here
		*/
		return null;
	}

	public Pair<List<Pair<String,String>>, List<Pair<String,String>>> ProofofScore(int student_id, int year){
		// Implement Code here
		return null;
	}
}
