package Includes;

public class DocumentNotFoundException extends Exception{
	
	public DocumentNotFoundException(){
		System.out.println("Document Not Found!");
	}

}
