package Includes;

public class EmptyStackException extends Exception{
	
	public EmptyStackException(){
		System.out.println("Error: Stack Empty");
	}

}
