package Includes;

public class AuthenticationFailedException extends Exception{
	
	public AuthenticationFailedException(){
		System.out.println("Authentication Failed!");
	}

}