import Includes.*;
import java.util.*;

public class MerkleTree{
	
	// Check the TreeNode.java file for more details
	public TreeNode rootnode;
	public int numdocs;

	public String Build(String[] documents){
		// Implement Code here
		return "";
	}

	/* 
		Pair is a generic data structure defined in the Pair.java file
		It has two attributes - First and Second, that can be set either manually or
		using the constructor

		Edit: The constructor is added
	*/
		
	public List<Pair<String,String>> QueryDocument(int doc_idx){
		// Implement Code here
		return new ArrayList<Pair<String,String>>(3);
	}

	public static boolean Authenticate(List<Pair<String,String>> path, String summary){
		// Implement Code here
		return false;
	}

	public String UpdateDocument(int doc_idx, String new_document){		
		// Implement Code here
		return "";
	}
}