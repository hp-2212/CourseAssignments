public class TreeNode{
	public TreeNode parent;
	public TreeNode left;
	public TreeNode right;
	public String val;
	public boolean isLeaf;
	public int numberLeaves;
	public String maxleafval;
	public String minleafval;
	public int balanceFactor;
		
	public TreeNode SingleLeftRotation(){
		//Implement your code here
		return null;
	}
	
	public TreeNode SingleRightRotation(){
		//Implement your code here
		return null;
	}
	
	public TreeNode DoubleLeftRightRotation(){
		//Implement your code here
		return null;
	}
	
	public TreeNode DoubleRightLeftRotation(){
		//Implement your code here
		return null;
	}
}

