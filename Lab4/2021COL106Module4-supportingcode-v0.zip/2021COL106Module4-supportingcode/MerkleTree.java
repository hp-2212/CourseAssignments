import Includes.*;
import java.util.*;
import java.lang.Math;

public class MerkleTree{
	//check TreeNode.java for more details
	public TreeNode rootnode;
	public int numdocs;
	

	public String InsertDocument(String document){
		//Implement your code here
		return "";
	}
	
	public String DeleteDocument(String document){
		//Implement your code here
		return "";
	}
}


